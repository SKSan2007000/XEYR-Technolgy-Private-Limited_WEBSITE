# Deployment Requirements
- **Platform:** Linux VPS / Cloud Platform
- **Hosting / Domain Setup:** Standard HTTPS / NGINX reverse proxy
- **Database:** PostgreSQL 17
