# Testing & QA Requirements
- **Testing Standard:** Unit and Integration Tests for Critical Workflows
- **Coverage Goal:** At least 80% coverage on critical business workflows.
