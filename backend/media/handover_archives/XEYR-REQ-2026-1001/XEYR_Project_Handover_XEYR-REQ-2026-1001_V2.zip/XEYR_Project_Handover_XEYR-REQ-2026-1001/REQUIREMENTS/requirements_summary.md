# Detailed Requirements: Apex Smart Dispatch & Fleet OS

## 1. Functional Requirements
Dispatcher creates trip -> Driver accepts trip -> Status updates live -> Delivery OTP confirmed -> Automated invoice generated.

## 2. Technical Stack & Preferences
- **Framework:** Python Django 5.2 + Django REST Framework
- **Backend:** 
- **Database:** PostgreSQL 17 with spatial indexes
- **Integrations:** 
- **Deployment Platform:** Linux VPS (Docker Compose)

## 3. Scope of Work
Complete frontend, backend, database migrations, authentication, real-time map tracking, invoice exports.

## 4. Acceptance Criteria
All 4 deliverables operational, tests passing, zero unhandled 500 errors.
