# Testing & QA Requirements
- **Testing Standard:** Automated unit tests for booking logic and invoicing calculations.
- **Coverage Goal:** At least 80% coverage on critical business workflows.
