# Architecture Requirements
## Apex Smart Dispatch & Fleet OS

- **Core Technologies:** Python Django 5.2 + Django REST Framework
- **Database:** PostgreSQL 17 with spatial indexes
- **Security & Authorization:** CSRF protection, JWT session tokens, encrypted file uploads
- **Role Permissions:** Standard Role-Based Access Control

### Security Guidelines for Developers
1. Never commit `.env` or credentials into version control.
2. Enforce CSRF protection and rate limiting on all public endpoints.
3. Validate and sanitize all user input server-side.
4. Restrict confidential assets to authenticated, authorized users.
