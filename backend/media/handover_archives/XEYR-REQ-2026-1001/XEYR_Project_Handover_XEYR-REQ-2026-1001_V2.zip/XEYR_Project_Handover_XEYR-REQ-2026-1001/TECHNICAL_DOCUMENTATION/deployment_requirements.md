# Deployment Requirements
- **Platform:** Linux VPS (Docker Compose)
- **Hosting / Domain Setup:** Ubuntu 24.04 LTS VPS, Docker, NGINX reverse proxy, SSL certificate.
- **Database:** PostgreSQL 17 with spatial indexes
