# Architecture Requirements
## Project A

- **Core Technologies:** Python Django + DRF
- **Database:** PostgreSQL 17
- **Security & Authorization:** CSRF, Rate Limiting, Input Validation, Protected File Storage
- **Role Permissions:** Standard Role-Based Access Control

### Security Guidelines for Developers
1. Never commit `.env` or credentials into version control.
2. Enforce CSRF protection and rate limiting on all public endpoints.
3. Validate and sanitize all user input server-side.
4. Restrict confidential assets to authenticated, authorized users.
